package steps;


import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import page.GooglePage;


public class GoogleSteps {
    GooglePage googlePage = new GooglePage();

    @Given("^Iam on the google search page$")
    public void navigateToGoogle() throws Throwable {
        googlePage.navigateToGoogle();
    }

    @When("^I enter a search criteria$")
    public void enterSearchCriteria() throws Throwable {

    }

    @And("^click on the search button$")
    public void clickOnSearchButton() throws Throwable {

    }

    @Then("^The results match the criteria$")
    public void validateResults() throws Throwable {

    }
}
